package com.verizon.delphi.model;

import java.util.List;

public class ModCardInfo {

	private String id;
	private String label;
	private String _class;
	private List<ModuleInfo> children;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String get_class() {
		return _class;
	}
	public void set_class(String _class) {
		this._class = _class;
	}
	public List<ModuleInfo> getChildren() {
		return children;
	}
	public void setChildren(List<ModuleInfo> children) {
		this.children = children;
	}
	
}
