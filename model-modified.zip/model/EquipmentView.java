package com.verizon.delphi.model;

import java.util.List;

public class EquipmentView {

	private String id;
	private String label;
	public List<EquipNodeInfo> getChildren() {
		return children;
	}
	public void setChildren(List<EquipNodeInfo> children) {
		this.children = children;
	}
	private List<EquipNodeInfo> children;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	
}
