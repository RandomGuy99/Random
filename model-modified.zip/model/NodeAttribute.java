package com.verizon.delphi.model;

import java.util.List;


public class NodeAttribute  {

private String ownership;
private List<String> availableCmds;
private String tid;
private String role;
private List<String> conditions;
private String model;
private String degree;
public String getDegree() {
	return degree;
}
public void setDegree(String degree) {
	this.degree = degree;
}
private List<AidsInfo> aidlist;

public String getOwnership() {
	return ownership;
}
public void setOwnership(String ownership) {
	this.ownership = ownership;
}

public List<String> getAvailableCmds() {
	return availableCmds;
}
public void setAvailableCmds(List<String> availableCmds) {
	this.availableCmds = availableCmds;
}
public String getTid() {
	return tid;
}
public void setTid(String tid) {
	this.tid = tid;
}

public List<AidsInfo> getAidlist() {
	return aidlist;
}
public void setAidlist(List<AidsInfo> aidlist) {
	this.aidlist = aidlist;
}
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public List<String> getConditions() {
	return conditions;
}
public void setConditions(List<String> conditions) {
	this.conditions = conditions;
}
public String getModel() {
	return model;
}
public void setModel(String model) {
	this.model = model;
}
private String nodeId;

public String getNodeId() {
	return nodeId;
}

public void setNodeId(String nodeId) {
	this.nodeId = nodeId;
}

 
}