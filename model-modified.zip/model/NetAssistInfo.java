package com.verizon.delphi.model;

import org.json.simple.JSONObject;

public class NetAssistInfo {
	

	private TopologyResponse topologyResponse;
	private String degree;
	private String model;
	private String tid;
	private JSONObject netAssistResponse;
	public JSONObject getNetAssistResponse() {
		return netAssistResponse;
	}
	public void setNetAssistResponse(JSONObject netAssistResponse) {
		this.netAssistResponse = netAssistResponse;
	}
	public TopologyResponse getTopologyResponse() {
		return topologyResponse;
	}
	public void setTopologyResponse(TopologyResponse topologyResponse) {
		this.topologyResponse = topologyResponse;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getTid() {
		return tid;
	}
	public void setTid(String tid) {
		this.tid = tid;
	}
	
}