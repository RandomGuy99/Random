package com.verizon.delphi.model;

import java.util.List;

public class ModulePortInfo {
	
	private List<ModCardInfo> mchildren;
	private List<PortCardInfo> pchildren;
	public List<ModCardInfo> getMchildren() {
		return mchildren;
	}
	public void setMchildren(List<ModCardInfo> mchildren) {
		this.mchildren = mchildren;
	}
	public List<PortCardInfo> getPchildren() {
		return pchildren;
	}
	public void setPchildren(List<PortCardInfo> pchildren) {
		this.pchildren = pchildren;
	}
	
}
