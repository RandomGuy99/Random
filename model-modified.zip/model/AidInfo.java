package com.verizon.delphi.model;


public class AidInfo {

	private String aid;
	public String getAid() {
		return aid;
	}
	public void setAid(String aid) {
		this.aid = aid;
	}
	public String getRateCode() {
		return rateCode;
	}
	public void setRateCode(String rateCode) {
		this.rateCode = rateCode;
	}
	private String rateCode;
	
/*	public AidInfo(String aid, String rateCode)
	{
	    this.aid = aid;
	    this.rateCode = rateCode;

	}*/
	@Override
	public boolean equals(Object obj) {
	    if(obj instanceof AidInfo)
	    {

	    	AidInfo temp = (AidInfo) obj;
	        if(this.aid.hashCode()==temp.aid.hashCode()) 
	        {
	        		return true;
	        }
	    }
	    return false;

	}
	@Override
	public int hashCode() {

	    return (this.aid.hashCode());        
	}
	
}