
package com.verizon.www.wfm.Snaketest;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.verizon.wfm.snaketest package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _UPDATEPOSTBERTREQUEST_QNAME = new QName("http://www.verizon.com/wfm/SnakeTest", "UPDATEPOSTBERTREQUEST");
    private final static QName _UpdatePostBertList_QNAME = new QName("http://www.verizon.com/wfm/SnakeTest", "UpdatePostBertList");
    private final static QName _POSTMESSAGEREQUEST_QNAME = new QName("http://www.verizon.com/wfm/SnakeTest", "POSTMESSAGEREQUEST");
    private final static QName _PostMessageList_QNAME = new QName("http://www.verizon.com/wfm/SnakeTest", "PostMessageList");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.verizon.wfm.snaketest
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link POSTRESPONSESTATUS }
     * 
     */
    public POSTRESPONSESTATUS createPOSTRESPONSESTATUS() {
        return new POSTRESPONSESTATUS();
    }

    /**
     * Create an instance of {@link UPDATEPOSTBERTRESPONSE }
     * 
     */
    public UPDATEPOSTBERTRESPONSE createUPDATEPOSTBERTRESPONSE() {
        return new UPDATEPOSTBERTRESPONSE();
    }

    /**
     * Create an instance of {@link UPDATEPOSTBERTREQUEST }
     * 
     */
    public UPDATEPOSTBERTREQUEST createUPDATEPOSTBERTREQUEST() {
        return new UPDATEPOSTBERTREQUEST();
    }

    /**
     * Create an instance of {@link UpdatePostBertList }
     * 
     */
    public UpdatePostBertList createUpdatePostBertList() {
        return new UpdatePostBertList();
    }

    /**
     * Create an instance of {@link POSTMESSAGEREQUEST }
     * 
     */
    public POSTMESSAGEREQUEST createPOSTMESSAGEREQUEST() {
        return new POSTMESSAGEREQUEST();
    }

    /**
     * Create an instance of {@link PostMessageList }
     * 
     */
    public PostMessageList createPostMessageList() {
        return new PostMessageList();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UPDATEPOSTBERTREQUEST }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.verizon.com/wfm/SnakeTest", name = "UPDATEPOSTBERTREQUEST")
    public JAXBElement<UPDATEPOSTBERTREQUEST> createUPDATEPOSTBERTREQUEST(UPDATEPOSTBERTREQUEST value) {
        return new JAXBElement<UPDATEPOSTBERTREQUEST>(_UPDATEPOSTBERTREQUEST_QNAME, UPDATEPOSTBERTREQUEST.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdatePostBertList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.verizon.com/wfm/SnakeTest", name = "UpdatePostBertList")
    public JAXBElement<UpdatePostBertList> createUpdatePostBertList(UpdatePostBertList value) {
        return new JAXBElement<UpdatePostBertList>(_UpdatePostBertList_QNAME, UpdatePostBertList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link POSTMESSAGEREQUEST }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.verizon.com/wfm/SnakeTest", name = "POSTMESSAGEREQUEST")
    public JAXBElement<POSTMESSAGEREQUEST> createPOSTMESSAGEREQUEST(POSTMESSAGEREQUEST value) {
        return new JAXBElement<POSTMESSAGEREQUEST>(_POSTMESSAGEREQUEST_QNAME, POSTMESSAGEREQUEST.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PostMessageList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.verizon.com/wfm/SnakeTest", name = "PostMessageList")
    public JAXBElement<PostMessageList> createPostMessageList(PostMessageList value) {
        return new JAXBElement<PostMessageList>(_PostMessageList_QNAME, PostMessageList.class, null, value);
    }

}
