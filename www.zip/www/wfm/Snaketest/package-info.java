@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.verizon.com/wfm/SnakeTest", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.verizon.www.wfm.Snaketest;
