
package com.verizon.www.wfm.Snaketest;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for PostMessageListType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PostMessageListType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SNAKE_TEST_ID " type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="BERT_ID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="USER_Id" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="DATESTAMP" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *         &lt;element name="SEVERITY " type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="MESSAGE" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PostMessageListType", propOrder = {
    "snaketestid",
    "bertid",
    "userId",
    "datestamp",
    "severity",
    "message"
})
public class PostMessageList {

    @XmlElement(name = "SNAKE_TEST_ID", required = true)
    protected String snaketestid;
    @XmlElement(name = "BERT_ID", required = true)
    protected String bertid;
    @XmlElement(name = "USER_Id", required = true)
    protected String userId;
    @XmlElement(name = "DATESTAMP", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar datestamp;
    @XmlElement(name = "SEVERITY", required = true)
    protected String severity;
    @XmlElement(name = "MESSAGE", required = true)
    protected String message;

    /**
     * Gets the value of the snaketestid0020 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSNAKETESTID() {
        return snaketestid;
    }

    /**
     * Sets the value of the snaketestid0020 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSNAKETESTID(String value) {
        this.snaketestid = value;
    }

    /**
     * Gets the value of the bertid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBERTID() {
        return bertid;
    }

    /**
     * Sets the value of the bertid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBERTID(String value) {
        this.bertid = value;
    }

    /**
     * Gets the value of the userId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUSERId() {
        return userId;
    }

    /**
     * Sets the value of the userId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUSERId(String value) {
        this.userId = value;
    }

    /**
     * Gets the value of the datestamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDATESTAMP() {
        return datestamp;
    }

    /**
     * Sets the value of the datestamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDATESTAMP(XMLGregorianCalendar value) {
        this.datestamp = value;
    }

    /**
     * Gets the value of the severity0020 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSEVERITY() {
        return severity;
    }

    /**
     * Sets the value of the severity0020 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSEVERITY(String value) {
        this.severity = value;
    }

    /**
     * Gets the value of the message property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMESSAGE() {
        return message;
    }

    /**
     * Sets the value of the message property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMESSAGE(String value) {
        this.message = value;
    }

}
