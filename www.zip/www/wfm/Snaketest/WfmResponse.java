package com.verizon.www.wfm.Snaketest;

import java.math.BigDecimal;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.verizon.delphi.msvcs.model.EthernetSnakeTest;

public class WfmResponse {

	public static UPDATEPOSTBERTREQUEST createUpdateRequest(EthernetSnakeTest response) {
		ObjectFactory obj = new ObjectFactory();
		UPDATEPOSTBERTREQUEST upbr = obj.createUPDATEPOSTBERTREQUEST();

		UpdatePostBertList upbl = obj.createUpdatePostBertList();
		upbl.setBERTID(response.getBERT_ID());
		upbl.setROUTERNAME(response.getRouter());
		upbl.setRESULTTIME(response.getDatestamp().toString());
		upbl.setSTATE(response.getState());
		upbl.setCLEARED(response.getCleared());
		upbl.setINPUTRATE(new BigDecimal(response.getInput_rate()));
		upbl.setOUTPUTRATE(new BigDecimal(response.getOutput_rate()));
		upbl.setINPUTERROR(new BigDecimal(response.getInput_error()));
		upbl.setOUTPUTERROR(new BigDecimal(response.getOutput_error()));
		upbl.setINPUTFRAME(new BigDecimal(response.getInput_frame()));
		upbl.setINPUTCRC(new BigDecimal(response.getInput_CRC()));
		upbl.setOUTPUTCARRIER(new BigDecimal(response.getOutput_carrier()));
		upbl.setOUTPUTCOLLISION(new BigDecimal(response.getOutput_collision()));
		upbl.setSNAKETESTID(response.getTest_id());

		upbr.getUpdatePostBertList().add(upbl);

		/*upbl.setBERTID("E-RALN-549297");
		upbl.setROUTERNAME("106.40.22.159");
		upbl.setRESULTTIME("29-NOV-16 11.13.10.209440000");
		upbl.setSTATE("up");
		upbl.setCLEARED("never");
		upbl.setINPUTRATE(new BigDecimal(0));
		upbl.setOUTPUTRATE(new BigDecimal(0));
		upbl.setINPUTERROR(new BigDecimal(0));
		upbl.setOUTPUTERROR(new BigDecimal(0));
		upbl.setINPUTFRAME(new BigDecimal(0));
		upbl.setINPUTCRC(new BigDecimal(0));
		upbl.setOUTPUTCARRIER(new BigDecimal(0));
		upbl.setOUTPUTCOLLISION(new BigDecimal(0));
		upbl.setSNAKETESTID("4532");

		upbr.getUpdatePostBertList().add(upbl);*/
	 // upbr.getUpdatePostBertList().addAll(response);

		return upbr;
	}

	public static POSTMESSAGEREQUEST createPostRequest(List<PostMessageList> response)
			throws DatatypeConfigurationException {
		ObjectFactory obj = new ObjectFactory();
		POSTMESSAGEREQUEST pmr = obj.createPOSTMESSAGEREQUEST();
		PostMessageList pml = obj.createPostMessageList();
		GregorianCalendar gcal = new GregorianCalendar();
		XMLGregorianCalendar xgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
		pml.setSNAKETESTID("3456");
		pml.setBERTID("32343");
		pml.setDATESTAMP(xgcal);
		pml.setMESSAGE("Started");
		pml.setSEVERITY("Informational");
		pml.setUSERId("wfm");
		// pmr.getPostMessageList().addAll(response);
		pmr.getPostMessageList().add(pml);
		return pmr;
	}
}
