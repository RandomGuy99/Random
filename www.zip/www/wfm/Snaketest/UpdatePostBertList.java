
package com.verizon.www.wfm.Snaketest;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UpdatePostBertListType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdatePostBertListType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SNAKE_TEST_ID " type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="BERT_ID" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="RESULT_TIME" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="ROUTER_NAME" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="STATE " type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="CLEARED" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="INPUT_RATE" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="OUTPUT_RATE" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="INPUT_ERROR" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="OUTPUT_ERROR " type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="OUTPUT_CARRIER" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="OUTPUT_COLLISION " type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="INPUT_FRAME" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="INPUT_CRC" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="SECTION_ES" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="SECTION_SES " type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="SECTION_SEFS" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="SECTION_LOS " type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="SECTION_LOF" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="SECTION_BIP" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="LINE_ES" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="LINE_SES " type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="LINE_RDI" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="LINE_AIS" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="LINE_BIP" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="PATH_ES" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="PATH_SES " type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="PATH_AIS" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="PATH_BIP " type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="PATH_LOP" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="PATH_UNEQ" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="PATH_PLM" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdatePostBertList", propOrder = {
    "snaketestid",
    "bertid",
    "resulttime",
    "routername",
    "state",
    "cleared",
    "inputrate",
    "outputrate",
    "inputerror",
    "outputerror",
    "outputcarrier",
    "outputcollision",
    "inputframe",
    "inputcrc",
    "sectiones",
    "sectionses",
    "sectionsefs",
    "sectionlos",
    "sectionlof",
    "sectionbip",
    "linees",
    "lineses",
    "linerdi",
    "lineais",
    "linebip",
    "pathes",
    "pathses",
    "pathais",
    "pathbip",
    "pathlop",
    "pathuneq",
    "pathplm"
})
public class UpdatePostBertList {

    @XmlElement(name = "SNAKE_TEST_ID", required = true)
    protected String snaketestid;
    @XmlElement(name = "BERT_ID", required = true)
    protected String bertid;
    @XmlElement(name = "RESULT_TIME", required = true)
    protected String resulttime;
    @XmlElement(name = "ROUTER_NAME", required = true)
    protected String routername;
    @XmlElement(name = "STATE", required = true)
    protected String state;
    @XmlElement(name = "CLEARED", required = true)
    protected String cleared;
    @XmlElement(name = "INPUT_RATE", required = true)
    protected BigDecimal inputrate;
    @XmlElement(name = "OUTPUT_RATE", required = true)
    protected BigDecimal outputrate;
    @XmlElement(name = "INPUT_ERROR", required = true)
    protected BigDecimal inputerror;
    @XmlElement(name = "OUTPUT_ERROR", required = true)
    protected BigDecimal outputerror;
    @XmlElement(name = "OUTPUT_CARRIER", required = true)
    protected BigDecimal outputcarrier;
    @XmlElement(name = "OUTPUT_COLLISION", required = true)
    protected BigDecimal outputcollision;
    @XmlElement(name = "INPUT_FRAME", required = true)
    protected BigDecimal inputframe;
    @XmlElement(name = "INPUT_CRC", required = true)
    protected BigDecimal inputcrc;
    @XmlElement(name = "SECTION_ES", required = true)
    protected BigDecimal sectiones;
    @XmlElement(name = "SECTION_SES", required = true)
    protected BigDecimal sectionses;
    @XmlElement(name = "SECTION_SEFS", required = true)
    protected BigDecimal sectionsefs;
    @XmlElement(name = "SECTION_LOS", required = true)
    protected BigDecimal sectionlos;
    @XmlElement(name = "SECTION_LOF", required = true)
    protected BigDecimal sectionlof;
    @XmlElement(name = "SECTION_BIP", required = true)
    protected BigDecimal sectionbip;
    @XmlElement(name = "LINE_ES", required = true)
    protected BigDecimal linees;
    @XmlElement(name = "LINE_SES", required = true)
    protected BigDecimal lineses;
    @XmlElement(name = "LINE_RDI", required = true)
    protected BigDecimal linerdi;
    @XmlElement(name = "LINE_AIS", required = true)
    protected BigDecimal lineais;
    @XmlElement(name = "LINE_BIP", required = true)
    protected BigDecimal linebip;
    @XmlElement(name = "PATH_ES", required = true)
    protected BigDecimal pathes;
    @XmlElement(name = "PATH_SES", required = true)
    protected BigDecimal pathses;
    @XmlElement(name = "PATH_AIS", required = true)
    protected BigDecimal pathais;
    @XmlElement(name = "PATH_BIP", required = true)
    protected BigDecimal pathbip;
    @XmlElement(name = "PATH_LOP", required = true)
    protected BigDecimal pathlop;
    @XmlElement(name = "PATH_UNEQ", required = true)
    protected BigDecimal pathuneq;
    @XmlElement(name = "PATH_PLM", required = true)
    protected BigDecimal pathplm;

    /**
     * Gets the value of the snaketestid0020 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSNAKETESTID() {
        return snaketestid;
    }

    /**
     * Sets the value of the snaketestid0020 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSNAKETESTID(String value) {
        this.snaketestid = value;
    }

    /**
     * Gets the value of the bertid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBERTID() {
        return bertid;
    }

    /**
     * Sets the value of the bertid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBERTID(String value) {
        this.bertid = value;
    }

    /**
     * Gets the value of the resulttime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRESULTTIME() {
        return resulttime;
    }

    /**
     * Sets the value of the resulttime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRESULTTIME(String value) {
        this.resulttime = value;
    }

    /**
     * Gets the value of the routername property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getROUTERNAME() {
        return routername;
    }

    /**
     * Sets the value of the routername property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setROUTERNAME(String value) {
        this.routername = value;
    }

    /**
     * Gets the value of the state0020 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSTATE() {
        return state;
    }

    /**
     * Sets the value of the state0020 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSTATE(String value) {
        this.state = value;
    }

    /**
     * Gets the value of the cleared property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCLEARED() {
        return cleared;
    }

    /**
     * Sets the value of the cleared property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCLEARED(String value) {
        this.cleared = value;
    }

    /**
     * Gets the value of the inputrate property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getINPUTRATE() {
        return inputrate;
    }

    /**
     * Sets the value of the inputrate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setINPUTRATE(BigDecimal value) {
        this.inputrate = value;
    }

    /**
     * Gets the value of the outputrate property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOUTPUTRATE() {
        return outputrate;
    }

    /**
     * Sets the value of the outputrate property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOUTPUTRATE(BigDecimal value) {
        this.outputrate = value;
    }

    /**
     * Gets the value of the inputerror property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getINPUTERROR() {
        return inputerror;
    }

    /**
     * Sets the value of the inputerror property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setINPUTERROR(BigDecimal value) {
        this.inputerror = value;
    }

    /**
     * Gets the value of the outputerror0020 property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOUTPUTERROR() {
        return outputerror;
    }

    /**
     * Sets the value of the outputerror0020 property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOUTPUTERROR(BigDecimal value) {
        this.outputerror = value;
    }

    /**
     * Gets the value of the outputcarrier property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOUTPUTCARRIER() {
        return outputcarrier;
    }

    /**
     * Sets the value of the outputcarrier property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOUTPUTCARRIER(BigDecimal value) {
        this.outputcarrier = value;
    }

    /**
     * Gets the value of the outputcollision0020 property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOUTPUTCOLLISION() {
        return outputcollision;
    }

    /**
     * Sets the value of the outputcollision0020 property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOUTPUTCOLLISION(BigDecimal value) {
        this.outputcollision = value;
    }

    /**
     * Gets the value of the inputframe property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getINPUTFRAME() {
        return inputframe;
    }

    /**
     * Sets the value of the inputframe property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setINPUTFRAME(BigDecimal value) {
        this.inputframe = value;
    }

    /**
     * Gets the value of the inputcrc property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getINPUTCRC() {
        return inputcrc;
    }

    /**
     * Sets the value of the inputcrc property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setINPUTCRC(BigDecimal value) {
        this.inputcrc = value;
    }

    /**
     * Gets the value of the sectiones property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSECTIONES() {
        return sectiones;
    }

    /**
     * Sets the value of the sectiones property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSECTIONES(BigDecimal value) {
        this.sectiones = value;
    }

    /**
     * Gets the value of the sectionses0020 property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSECTIONSES() {
        return sectionses;
    }

    /**
     * Sets the value of the sectionses0020 property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSECTIONSES(BigDecimal value) {
        this.sectionses = value;
    }

    /**
     * Gets the value of the sectionsefs property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSECTIONSEFS() {
        return sectionsefs;
    }

    /**
     * Sets the value of the sectionsefs property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSECTIONSEFS(BigDecimal value) {
        this.sectionsefs = value;
    }

    /**
     * Gets the value of the sectionlos0020 property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSECTIONLOS() {
        return sectionlos;
    }

    /**
     * Sets the value of the sectionlos0020 property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSECTIONLOS(BigDecimal value) {
        this.sectionlos = value;
    }

    /**
     * Gets the value of the sectionlof property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSECTIONLOF() {
        return sectionlof;
    }

    /**
     * Sets the value of the sectionlof property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSECTIONLOF(BigDecimal value) {
        this.sectionlof = value;
    }

    /**
     * Gets the value of the sectionbip property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSECTIONBIP() {
        return sectionbip;
    }

    /**
     * Sets the value of the sectionbip property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSECTIONBIP(BigDecimal value) {
        this.sectionbip = value;
    }

    /**
     * Gets the value of the linees property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getLINEES() {
        return linees;
    }

    /**
     * Sets the value of the linees property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setLINEES(BigDecimal value) {
        this.linees = value;
    }

    /**
     * Gets the value of the lineses0020 property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getLINESES() {
        return lineses;
    }

    /**
     * Sets the value of the lineses0020 property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setLINESES(BigDecimal value) {
        this.lineses= value;
    }

    /**
     * Gets the value of the linerdi property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getLINERDI() {
        return linerdi;
    }

    /**
     * Sets the value of the linerdi property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setLINERDI(BigDecimal value) {
        this.linerdi = value;
    }

    /**
     * Gets the value of the lineais property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getLINEAIS() {
        return lineais;
    }

    /**
     * Sets the value of the lineais property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setLINEAIS(BigDecimal value) {
        this.lineais = value;
    }

    /**
     * Gets the value of the linebip property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getLINEBIP() {
        return linebip;
    }

    /**
     * Sets the value of the linebip property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setLINEBIP(BigDecimal value) {
        this.linebip = value;
    }

    /**
     * Gets the value of the pathes property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPATHES() {
        return pathes;
    }

    /**
     * Sets the value of the pathes property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPATHES(BigDecimal value) {
        this.pathes = value;
    }

    /**
     * Gets the value of the pathses0020 property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPATHSES() {
        return pathses;
    }

    /**
     * Sets the value of the pathses0020 property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPATHSES(BigDecimal value) {
        this.pathses = value;
    }

    /**
     * Gets the value of the pathais property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPATHAIS() {
        return pathais;
    }

    /**
     * Sets the value of the pathais property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPATHAIS(BigDecimal value) {
        this.pathais = value;
    }

    /**
     * Gets the value of the pathbip0020 property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPATHBIP() {
        return pathbip;
    }

    /**
     * Sets the value of the pathbip0020 property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPATHBIP(BigDecimal value) {
        this.pathbip = value;
    }

    /**
     * Gets the value of the pathlop property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPATHLOP() {
        return pathlop;
    }

    /**
     * Sets the value of the pathlop property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPATHLOP(BigDecimal value) {
        this.pathlop = value;
    }

    /**
     * Gets the value of the pathuneq property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPATHUNEQ() {
        return pathuneq;
    }

    /**
     * Sets the value of the pathuneq property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPATHUNEQ(BigDecimal value) {
        this.pathuneq = value;
    }

    /**
     * Gets the value of the pathplm property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPATHPLM() {
        return pathplm;
    }

    /**
     * Sets the value of the pathplm property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPATHPLM(BigDecimal value) {
        this.pathplm = value;
    }

}
