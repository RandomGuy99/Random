package com.verizon.delphi.model;

import java.util.List;

public class NeatSourceInfo {
	
	
	private String ownership;
	public String getOwnership() {
		return ownership;
	}
	public void setOwnership(String ownership) {
		this.ownership = ownership;
	}
	public List<String> getAvailableCmds() {
		return availableCmds;
	}
	public void setAvailableCmds(List<String> availableCmds) {
		this.availableCmds = availableCmds;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	private List<String> availableCmds;
	private String role;	
	
}