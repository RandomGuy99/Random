package com.vz.ctas.ws.ivruCallDisposition;

import java.io.*;
import java.util.*;
//import java.util.regex.*;
import com.vz.ctas.ws.common.*;

public final class DClient {

   public static void main(String[] args) throws Exception
   {
       CtasIvruCallDispositionRequestMsg req;
       Properties props;

       try {
            if (args.length<=0) {
                System.out.println("Please provide the input file name");
                return;
            }
            String fileName=args[0];

            props = new Properties();
            FileInputStream fis = new FileInputStream(fileName);
            props.load(new BufferedInputStream(fis));

			processClientRequest( props );

       }
       catch (Exception exObj) {
            System.out.println("Caught exception <" + exObj +">");
			exObj.printStackTrace();
            return;
       }
   }

	private static void processClientRequest(
		Properties props
	) {
		try {
			CtasIvruCallDispositionResponseMsg rsp = null;
			CtasIvruCallDispositionRequestMsg req =
				CtasIvruCallDispositionRequestMsg.getInstance(props);
			System.out.println( "Client request=<" + req + ">" );
			rsp = IvruCallDispositionImpl.processRequest(req);
			System.out.println( "Client received "
				+ "response <" + rsp + ">" );
		}
		catch (Exception exObj) {
			System.out.println("Client: Caught exception <" + exObj +">");
			exObj.printStackTrace();
		}
	}

	private static boolean isDoubleDispatch( Properties props ) {
		Boolean isDoubleDispatch = Utils.getBooleanProp(props,"doubleDispatch");
		return ( isDoubleDispatch != null && isDoubleDispatch.booleanValue() );
	}

}

