package com.vz.ctas.ws.ivruCallDisposition;

import java.io.*;
import java.util.*;
import java.util.regex.*;
import com.vz.ctas.ws.common.*;

import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.Service;
import javax.xml.rpc.handler.*;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.HandlerRegistry;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.soap.*;

import com.vz.wsutil.ItwSecurityHandler;

public final class Client {

	private final static QName portName_ = new QName("IvruCallDispositionPort");
	private static ArrayList handlerList_ = new ArrayList();
	static {
		System.setProperty("weblogic.webservice.client.ssl.adapterclass",
			"com.vz.wsutil.JSSEAdapter");
		// Config should come from e.g., properties file
		Map handlerConfig = new HashMap();
			handlerConfig.put("username", "ctasWS");
			handlerConfig.put("password", "ctasWS11");
		handlerList_.add(new HandlerInfo(ItwSecurityHandler.class, handlerConfig, null));
		System.out.println("Client: static init: added ItwSecurityHandler");
	}

	private static class Utils {
		public static String getProp(Properties props, String propName) {
			String propVal = props.getProperty(propName);
			if (propVal==null) propVal="";
			return propVal;
		}

		public static String getProp(Properties props, String arg, String defaultVal) {
			return props.getProperty(arg, defaultVal);
		}

		public static Boolean getBooleanProp(Properties props, String propName) {
			String propVal = getProp(props, propName, null);
			if (propVal == null) {
				return null;
			}
			// case insensitively map "true" to true; all else to false
			return Boolean.valueOf( propVal );
		}

		public static Integer getIntegerProp(Properties props, String propName) {
			// case insensitively map "true" to true; all else to false
			Integer i = null;
			try {
				i = Integer.valueOf( getProp(props, propName) );
			} catch (NumberFormatException nfex) {
				nfex.printStackTrace();
			}
			return i;
		}

	}

   public static void main(String[] args) throws Exception
   {
       CtasIvruCallDispositionRequestMsg req;
       Properties props;

       try {
            if (args.length<=0) {
                System.out.println("Please provide the input file name");
                return;
            }
            String fileName=args[0];

            props = new Properties();
            FileInputStream fis = new FileInputStream(fileName);
            props.load(new BufferedInputStream(fis));

			processClientRequest( props );

       }
       catch (Exception exObj) {
            System.out.println("Caught exception <" + exObj +">");
			exObj.printStackTrace();
            return;
       }
   }

	private static void processClientRequest(
		Properties props
	) {
		try {
			IvruCallDispositionPort port = getWsPort( props );
			if ( port == null ) {
				System.out.println("Client request failed: port/url not found");
				return;
			}
			boolean isDoubleDispatch = isDoubleDispatch( props );
			CtasIvruCallDispositionResponseMsg rsp = null;
			CtasIvruCallDispositionRequestMsg req =
				CtasIvruCallDispositionRequestMsg.getInstance(props);
			System.out.println( "Client request=<" + req + ">" );
			rsp = port.processRequest(req);
			System.out.println( "Client received "
				+ (isDoubleDispatch ? "double-dispatch " : "")
				+ "response <" + rsp + ">" );
		}
		catch (Exception exObj) {
			System.out.println("Client: Caught exception <" + exObj +">");
			exObj.printStackTrace();
		}
	}

	private static IvruCallDispositionPort getWsPort( Properties props )
		throws IOException
	{
		String wsdlUrl = props.getProperty("wsdlUrl");
		if (wsdlUrl == null) {
			System.out.println("WSDL url not found");
			return null;
		}
		// Derive port from web-service implementation
		IvruCallDisposition_Impl ws = new IvruCallDisposition_Impl(wsdlUrl);
		int rc = setHandlerChain(ws, props);
		if ( rc != 0 ) {
			System.out.println("Client: getWsPort: Failed to add handlers");
		}
		//WeblogicSecurity.secureSession(ws);
		return ws.getIvruCallDispositionPort();
	}

	private static boolean isDoubleDispatch( Properties props ) {
		Boolean isDoubleDispatch = Utils.getBooleanProp(props,"doubleDispatch");
		return ( isDoubleDispatch != null && isDoubleDispatch.booleanValue() );
	}

	/**
	 Set handler chain for Service.
	 @param impl a Service (implementation)
	 */
	private static int setHandlerChain(Service impl) {
		return setHandlerChain(impl, handlerList_);
	}

	/**
	 Set handler chain for Service from specified properties.
	 @param impl a Service (implementation)
	 @param props specification for handler-chainler chain
	 */
	private static int setHandlerChain(Service impl, Properties props) {
		ArrayList handlerList = new ArrayList();
		Map handlerConfig = new HashMap();
			//handlerConfig.put("username", "ctasWS");
			//handlerConfig.put("password", "ctasWS11");
			handlerConfig.put("username", Utils.getProp(props,"itw.userName"));
			handlerConfig.put("password", Utils.getProp(props,"itw.userPassword"));
		handlerList.add(new HandlerInfo(ItwSecurityHandler.class, handlerConfig, null));
		System.out.println("Client: setHandlerChain: added ItwSecurityHandler");
		return setHandlerChain(impl, handlerList);
	}

	/**
	 Set handler chain for Service.
	 @param impl a Service (implementation)
	 @param handlerList handler-chain ArrayList for service
	 */
	private static int setHandlerChain(Service impl, ArrayList handlerList) {
		try {
			HandlerRegistry registry = impl.getHandlerRegistry();
			registry.setHandlerChain(portName_, handlerList);
		}
		catch (Exception exObj) {
			System.out.println("Client: setHandlerChain: Caught exception <" + exObj +">");
			exObj.printStackTrace();
			return 1;
		}
		return 0;
	}

}

