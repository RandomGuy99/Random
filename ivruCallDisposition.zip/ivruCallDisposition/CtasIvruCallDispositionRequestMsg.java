package com.vz.ctas.ws.ivruCallDisposition;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.SimpleTimeZone;
import java.util.Properties;
import java.util.logging.Logger;
import java.util.regex.*;
import java.io.Serializable;
import com.vz.ctas.ws.common.CircuitEnd;
import com.vz.ctas.ws.common.CircuitEndId;
import com.vz.ctas.ws.common.ClientAGR;
import com.vz.ctas.ws.common.HdslBenchmarksAGR;
import com.vz.ctas.ws.common.LoopMeasurementsAGR;
import com.vz.ctas.ws.common.QuickTestResultsAGR;
import com.vz.ctas.ws.common.QuickTestResultsId;
import com.vz.ctas.ws.common.ResponseCode;
import com.vz.ctas.ws.common.ResponseInfoAGR;
import com.vz.ctas.ws.common.TurnUpStatusAGR;
import com.vz.ctas.ws.common.WebServiceUtils;

public class CtasIvruCallDispositionRequestMsg implements Serializable {
	private ClientAGR clientAGR;
	private String systemId;
	private String transactionId;
	private String callDispositionCode;
	private String notReachedReason;
	private Date timeStamp;

	// Set and get methods
	public void setClientAGR( ClientAGR clientAGR ) { this.clientAGR=clientAGR; }
	public ClientAGR getClientAGR() { return clientAGR; }

	public void setSystemId( String systemId ) { this.systemId=systemId; }
	public String getSystemId() { return systemId; }

	public void setTransactionId( String transactionId ) { this.transactionId=transactionId; }
	public String getTransactionId() { return transactionId; }

	public void setCallDispositionCode( String callDispositionCode ) { this.callDispositionCode=callDispositionCode; }
	public String getCallDispositionCode() { return callDispositionCode; }

	public void setNotReachedReason( String notReachedReason ) { this.notReachedReason=notReachedReason; }
	public String getNotReachedReason() { return notReachedReason; }

	public void setTimeStamp( Date timeStamp ) { this.timeStamp=timeStamp; }
	public Date getTimeStamp() { return timeStamp; }


	private interface Patterns {
		// [+99.9, -99.9]
		// NB: A decimal point without a decimal digit is NOT valid
		Pattern vgplMeasurement = Pattern.compile("^[+-]?\\d{1,2}(\\.\\d)?$");
	}

	private static boolean isValidVgplMeasurement( String measurement ) {
		return (
			measurement != null &&
			Patterns.vgplMeasurement.matcher(measurement).matches() );
	}

	public boolean isValid(ResponseInfoAGR responseInfoAGR, Logger logger ) {
		final String MISSING = " missing from the input";
		final String INVALIDVGPL = " invalid: must be in range [-99.9, +99.9]";
		if (this.getClientAGR() == null) {
			responseInfoAGR.set(ResponseCode.MissingInfo, "clientAGR missing from the input");
			logger.warning("clientAGR missing from the input");
			return false;
		}
		if (this.getSystemId() == null || this.getSystemId().length() == 0) {
			responseInfoAGR.set(ResponseCode.MissingInfo, "systemId missing from the input");
			logger.warning("systemId missing from the input");
			return false;
		}
		if (this.getTransactionId() == null || this.getTransactionId().length() == 0) {
			responseInfoAGR.set(ResponseCode.MissingInfo, "transactionId missing from the input");
			logger.warning("transactionId missing from the input");
			return false;
		}
		if (this.getCallDispositionCode() == null || this.getCallDispositionCode().length() == 0) {
			responseInfoAGR.set(ResponseCode.MissingInfo, "callDispositionCode missing from the input");
			logger.warning("callDispositionCode missing from the input");
			return false;
		}
//		if (this.getNotReachedReason() == null || this.getNotReachedReason().length() == 0) {
//			responseInfoAGR.set(ResponseCode.MissingInfo, "notReachedReason missing from the input");
//			logger.warning("notReachedReason missing from the input");
//			return false;
//		}
		return true;
	}

	public String toString() {
		return ""
			+ "clientAGR=<" + this.getClientAGR() + "> "
			+ "systemId=<" + this.getSystemId() + "> "
			+ "transactionId=<" + this.getTransactionId() + "> "
			+ "callDispositionCode=<" + this.getCallDispositionCode() + "> "
			+ "notReachedReason=<" + this.getNotReachedReason() + "> "
			+ "timeStamp=<" + this.getTimeStamp() + "> "
			;
	}

	public void toLog( Logger logger ) {
		logger.info("Start of client request ============================================");
		logger.info("clientAGR = <" + this.getClientAGR() + ">");
		logger.info("systemId = <" + this.getSystemId() + ">");
		logger.info("transactionId = <" + this.getTransactionId() + ">");
		logger.info("callDispositionCode = <" + this.getCallDispositionCode() + ">");
		logger.info("notReachedReason = <" + this.getNotReachedReason() + ">");
		logger.info("timeStamp = <" + this.getTimeStamp() + ">");
		logger.info("End of client request ============================================");
	}


	// Factory methods --------------------------------------
	/**
	  @param
	  @return
	 */
	public static CtasIvruCallDispositionRequestMsg getInstance() {
		CtasIvruCallDispositionRequestMsg obj = new CtasIvruCallDispositionRequestMsg();
		obj.setClientAGR( null );
		obj.setSystemId( "" );
		obj.setTransactionId( "" );
		obj.setCallDispositionCode( "" );
		obj.setNotReachedReason( "" );
		obj.setTimeStamp( null );
		return obj;
	}

	/**
	  @param
	  @return
	 */
	public static CtasIvruCallDispositionRequestMsg getInstance( Properties props ) {
		CtasIvruCallDispositionRequestMsg obj = CtasIvruCallDispositionRequestMsg.getInstance();
		obj.setClientAGR(new ClientAGR());
		obj.getClientAGR().setClientName(Utils.getProp(props,"clientName"));
		obj.getClientAGR().setClientRequestID(Utils.getProp(props,"clientRequestID"));
		obj.setSystemId( Utils.getProp(props, "systemId") );
		obj.setTransactionId( Utils.getProp(props, "transactionId") );
		obj.setCallDispositionCode( Utils.getProp(props, "callDispositionCode") );
		obj.setNotReachedReason( Utils.getProp(props, "notReachedReason") );
		obj.setTimeStamp( Utils.getDateProp(props, "timeStamp", "yyyy/MM/dd-HH:mm:ss-z") );
		return obj;
	}

}

