package com.vz.ctas.ws.ivruCallDisposition;

import java.util.Collections;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.io.ObjectStreamException;
import java.util.logging.*;

public final class IvruCallDispositionCode {
	public static final IvruCallDispositionCode CUSTOMER_ACCEPTED_WITHOUT_DEMARC =
		new IvruCallDispositionCode("CUSTOMER_ACCEPTED_WITHOUT_DEMARC");
	public static final IvruCallDispositionCode CUSTOMER_ACCEPTED_WITH_DEMARC =
		new IvruCallDispositionCode("CUSTOMER_ACCEPTED_WITH_DEMARC");
	public static final IvruCallDispositionCode CUSTOMER_ANSWERED_BUT_DID_NOT_UTTER_A_GREETING =
		new IvruCallDispositionCode("CUSTOMER_ANSWERED_BUT_DID_NOT_UTTER_A_GREETING");
	public static final IvruCallDispositionCode CUSTOMER_ANSWERED_BUT_REQUESTED_CALL_BACK =
		new IvruCallDispositionCode("CUSTOMER_ANSWERED_BUT_REQUESTED_CALL_BACK");
	public static final IvruCallDispositionCode CUSTOMER_ANSWERED_BUT_SELECTED_AN_INVALID_OPTION =
		new IvruCallDispositionCode("CUSTOMER_ANSWERED_BUT_SELECTED_AN_INVALID_OPTION");
	public static final IvruCallDispositionCode CUSTOMER_INITIATED_TRANSFER_TO_AGENT_SUCCEEDED =
		new IvruCallDispositionCode("CUSTOMER_INITIATED_TRANSFER_TO_AGENT_SUCCEEDED");
	public static final IvruCallDispositionCode CUSTOMER_NOT_REACHED =
		new IvruCallDispositionCode("CUSTOMER_NOT_REACHED");
	public static final IvruCallDispositionCode CUSTOMER_REQUESTED_MORE_TIME =
		new IvruCallDispositionCode("CUSTOMER_REQUESTED_MORE_TIME");

	private static final IvruCallDispositionCode[] VALS = {
		CUSTOMER_ACCEPTED_WITHOUT_DEMARC,
		CUSTOMER_ACCEPTED_WITH_DEMARC,
		CUSTOMER_ANSWERED_BUT_DID_NOT_UTTER_A_GREETING,
		CUSTOMER_ANSWERED_BUT_REQUESTED_CALL_BACK,
		CUSTOMER_ANSWERED_BUT_SELECTED_AN_INVALID_OPTION,
		CUSTOMER_INITIATED_TRANSFER_TO_AGENT_SUCCEEDED,
		CUSTOMER_NOT_REACHED,
		CUSTOMER_REQUESTED_MORE_TIME,
	};

	public static final IvruCallDispositionCode getByName(String name) {
		Iterator iter = VALUES.iterator();
		while ( iter.hasNext() ) {
			IvruCallDispositionCode obj = (IvruCallDispositionCode)iter.next();
			if ( obj.toName().equals(name) ) { return obj; }
		}
		return null;
	};

	public IvruCallDispositionCode() { throw new ExceptionInInitializerError("do not use"); }
	private IvruCallDispositionCode(String name) { this.name = name; }

	public static final List VALUES =
		Collections.unmodifiableList(Arrays.asList(VALS));
	private static int nextOrdinal = 0;
	private final int ordinal = nextOrdinal++;
	private final String name;
	private Object readResolve()
			throws ObjectStreamException {
		return VALS[ordinal]; // Canonicalize
	}

	public String toString() {
		return this.name + "=" + this.ordinal;
	}
	public String toName() { return this.name; }
	public int toInt() { return this.ordinal; }
	public final boolean equals(Object that) { // needed if(f) extensible
		return super.equals(that);
	}
}
