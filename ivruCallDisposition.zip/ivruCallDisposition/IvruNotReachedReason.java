package com.vz.ctas.ws.ivruCallDisposition;

import java.util.Collections;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.io.ObjectStreamException;
import java.util.logging.*;

public final class IvruNotReachedReason {
	public static final IvruNotReachedReason ANSWERING_MACHINE =
		new IvruNotReachedReason("ANSWERING_MACHINE");
	public static final IvruNotReachedReason BUSY =
		new IvruNotReachedReason("BUSY");
	public static final IvruNotReachedReason FAX =
		new IvruNotReachedReason("FAX");
	public static final IvruNotReachedReason HANG_UP =
		new IvruNotReachedReason("HANG_UP");
	public static final IvruNotReachedReason RING_NO_ANSWER =
		new IvruNotReachedReason("RING_NO_ANSWER");
	public static final IvruNotReachedReason SYSTEM_ERROR =
		new IvruNotReachedReason("SYSTEM_ERROR");
	public static final IvruNotReachedReason WRONG_PARTY =
		new IvruNotReachedReason("WRONG_PARTY");

	private static final IvruNotReachedReason[] VALS = {
		ANSWERING_MACHINE,
		BUSY,
		FAX,
		HANG_UP,
		RING_NO_ANSWER,
		SYSTEM_ERROR,
		WRONG_PARTY,
	};

	public static final IvruNotReachedReason getByName(String name) {
		Iterator iter = VALUES.iterator();
		while ( iter.hasNext() ) {
			IvruNotReachedReason obj = (IvruNotReachedReason)iter.next();
			if ( obj.toName().equals(name) ) { return obj; }
		}
		return null;
	};

	public IvruNotReachedReason() { throw new ExceptionInInitializerError("do not use"); }
	private IvruNotReachedReason(String name) { this.name = name; }

	public static final List VALUES =
		Collections.unmodifiableList(Arrays.asList(VALS));
	private static int nextOrdinal = 0;
	private final int ordinal = nextOrdinal++;
	private final String name;
	private Object readResolve()
			throws ObjectStreamException {
		return VALS[ordinal]; // Canonicalize
	}

	public String toString() {
		return this.name + "=" + this.ordinal;
	}
	public String toName() { return this.name; }
	public int toInt() { return this.ordinal; }
	public final boolean equals(Object that) { // needed if(f) extensible
		return super.equals(that);
	}
}
