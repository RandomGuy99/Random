package com.vz.ctas.ws.ivruCallDisposition;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Vector;
import java.util.logging.*;

import com.vz.ctas.ws.common.ResponseCode;
import com.vz.ctas.ws.common.ResponseInfoAGR;

//import com.vz.ctas.common.AutotestEligibility;
//import com.vz.ctas.common.ScopeEligibility;
import com.vz.ctas.common.CircuitId;
import com.vz.ctas.common.CommonConfig;
import com.vz.ctas.common.CommonDBIfc;
import com.vz.ctas.common.CtasMsg;
import com.vz.ctas.common.CtasMsgIfc;
import com.vz.ctas.common.RouterConfig;
import com.vz.ctas.db.Query;
import com.vz.util.Quotify;

/**
 *  CTAS IvruCallDisposition Web Service
 *  @author <<<author>>>
 */

public final class IvruCallDispositionImpl {
	private static Logger logger = Logger.getLogger("IvruCallDispositionImpl");
	private static CtasMsgIfc testerIfc_;
	private final static String conf_vm_wfados_tableName_ = "CONF_VM_WFADOS";
	private final static Integer flowNum_;
	private final static Integer minutes_;
	private final static Properties ifcProps_;
	private final static DateFormat timeStampFormat_ =
		new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS000");
	private final static String DEFAULT_CALLMGR_PORTNUM = "39000";

	static {
		logger.info( "enter static block" );
		Properties props = CommonConfig.getProperties("ws.IvruCallDisposition");
		String partner = CommonConfig.getPartner();
		flowNum_ = Utils.getIntegerProp( props, "flownum", new Integer(1) );
		minutes_ = Utils.getIntegerProp( props, "minutes", new Integer(30) );

		ifcProps_ = new Properties();
		ifcProps_.setProperty("primary", "localhost");
		if (partner != null)
			ifcProps_.setProperty("secondary", partner);
		ifcProps_.setProperty("portnum",
			props.getProperty("portnum", DEFAULT_CALLMGR_PORTNUM));
		ifcProps_.setProperty("timeoutseconds", props.getProperty("timeoutseconds", "30"));
		ifcProps_.setProperty("maxtries", props.getProperty("maxtries", "2"));
		logger.info("ifcProps_=<" + ifcProps_ + ">");
		logger.info( "exit static block" );
	}

	private static String getClientString(
		final CtasIvruCallDispositionRequestMsg req
	) {
		return req.getClientAGR().toClientString();
	}

	private static boolean isValidRequest(
		final CtasIvruCallDispositionRequestMsg req,
		CtasIvruCallDispositionResponseMsg rsp
	) {
		if ( ! req.isValid(rsp.getResponseInfoAGR(), logger) ) {
			// ASSERT: response has been modified to reflect invalid conditions(s)
			return false;
		}
		if (null == IvruCallDispositionCode.getByName(req.getCallDispositionCode()) ) {
			logger.warning("Invalid IvruCallDispositionCode <"
				+ req.getCallDispositionCode() + ">" );
			return false;
		}
		// notReachedReason required ONLY for not-reached dispositionCodes
		// so validate here IFF non-null
		if (req.getNotReachedReason() != null &&
				null == IvruNotReachedReason.getByName(req.getNotReachedReason()) ) {
			logger.warning("Invalid IvruNotReachedReason <"
				+ req.getNotReachedReason() + ">" );
			return false;
		}
		// ... Add validations here ...
		return true;
	}

	private static CtasIvruCallDispositionResponseMsg getFinalResponse(
		CtasIvruCallDispositionRequestMsg req,
		CtasIvruCallDispositionResponseMsg rsp,
		long fromMilliSeconds
	) {
		// Forward with a default responseToGET object
		return getFinalResponse(req, rsp, new CtasMsg(""), fromMilliSeconds);
	}

	private static CtasIvruCallDispositionResponseMsg getFinalResponse(
		CtasIvruCallDispositionRequestMsg req,
		CtasIvruCallDispositionResponseMsg rsp,
		CtasMsg responseToGET,
		long fromMilliSeconds
	) {
		String clientString = req.getClientAGR().toClientString()
		                      ;
		if (writeToDB(req, rsp, responseToGET, fromMilliSeconds) < 0) {
			logger.severe("Error inserting into hist_ws_IvruCallDisposition table for: "
				+ clientString);
		}
		logger.fine( "concluded processing for <"
			+ getClientString(req) + "> rsp=<" + rsp + ">" );
		return rsp;
	}

	private static int writeToDB(
		CtasIvruCallDispositionRequestMsg req,
		CtasIvruCallDispositionResponseMsg rsp,
		long fromMilliSeconds
	) {
		// Forward with a default responseToGET object
		return writeToDB(req, rsp, new CtasMsg(""), fromMilliSeconds);
	}

	private static int writeToDB(
		CtasIvruCallDispositionRequestMsg req,
		CtasIvruCallDispositionResponseMsg rsp,
		CtasMsg responseToGET,
		long fromMilliSeconds
	) {
		long durationSeconds = ((new Date().getTime())-fromMilliSeconds)/1000;
		final String tableName = "hist_ws_ivrucalls";
		final String emptyQstr = "''";
		logger.info("Duration=" + durationSeconds);
		// Construct the INSERT query
		String[][] colVal = {
			{ "disposition", Quotify.quotify(
				req.getCallDispositionCode() +
				( req.getNotReachedReason() == null ?
				    "" : (" " + req.getNotReachedReason()) ) ) },
			{ "host", Quotify.quotify(req.getSystemId()) },
			{ "idnum", ""+req.getTransactionId() },
				// what to use for crtdate: now or VRU's timestamp?
			{ "crtdate", "current timestamp" },
			//{ "crtdate", Quotify.quotify(Db2.dateToDb2String(req.getTimeStamp())) },
			{ "numsec", ""+durationSeconds },
				// Set unavailable columns to empty strings (not nulls)
			{ "center", emptyQstr },
			{ "cktid", emptyQstr },
			{ "clo", emptyQstr },
			{ "demarcloc", emptyQstr },
			{ "demarcloc1", emptyQstr },
			{ "impcon", emptyQstr },
			{ "jack", emptyQstr },
			{ "jack1", emptyQstr },
			{ "ordernum", emptyQstr },
			{ "origin", emptyQstr },
			{ "pon", emptyQstr },
			{ "region", emptyQstr }, };
		StringBuffer qsb = new
			StringBuffer("INSERT INTO " + tableName + " (");
		// Append column names
		for (int i=0;  i < colVal.length;  i++ ) {
			qsb.append(colVal[i][0]).append(", "); }
		qsb.setLength(qsb.length()-2);  // delete trailing comma+space
		qsb.append(") VALUES (");
		// Append column values
		for (int i=0;  i < colVal.length;  i++ ) {
			qsb.append(colVal[i][1]).append(", "); }
		qsb.setLength(qsb.length()-2);  // delete trailing comma+space
		qsb.append(")");
		String qry = qsb.toString();
		logger.info("About to issue query <" + qry + ">");
		Query q = new Query(qry);
		if (!q.isValid()) {
			return -1;
		}
		return 0;
	}


	/**
	 * Create a new CtasMsgIfc instance, configured for this service and the
	 * CtasMsg corresponding to the service request.
	 * Should be public constructor/factory-method in CtasMsgIfc.java:
	 *	public CtasMsgIfc(CtasMsg ctasReq, Properties props) { }
	 * OR generic WS method.
	 *
	 * @param ctasReq  the CtasMsg corresponding to the service request
	 *                 from the client
	 * @return         a new, fully initialized CtasMsgIfc instance
	 */
	private static CtasMsgIfc newCtasMsgIfc(
		final CtasMsg ctasReq
	) {
		Properties props = new Properties(ifcProps_);
		ArrayList hosts = RouterConfig.getInstance().getHosts(ctasReq);
		if (hosts != null) {
			if (hosts.size() > 0) {
				props.setProperty("primary", (String)hosts.get(0));
			}
			if (hosts.size() > 1) {
				props.setProperty("secondary", (String)hosts.get(1));
			}
		}
		// Guarantee that ctasReq is alwasy sent to the server that originated
		// the IvruCallRequest.
		// ASSERT: ctasReq.getValue("SYSTEM_ID") always set to hostname of
		// originator of IvruCallRequest
		props.setProperty("primary", ctasReq.getValue("SYSTEM_ID"));
		props.setProperty("secondary",
			CommonConfig.getPartner(ctasReq.getValue("SYSTEM_ID")) );
		CtasMsgIfc ctasIfc = new CtasMsgIfc(props);
		if (!ctasIfc.isValid()) {
			logger.warning("failed to create valid CtasMsgIfc with properties: " + props);
		}
		return( new CtasMsgIfc(props) );
	}

//	/**
//	 Copied from CommonConfig.java to avoid complicated patching - 2008-08-20
//	 Must be replaced eventually by CommonConfig.getPartner(String)
//	 --------------------------------------------------------------
//	 Returns failover partner of specified host.
//	 @param hostName host whose partner is sought
//	 @return  specified host's failover partner
//	 */
//	public static String getPartner(String hostName) {
//		if (hostName == null) {
//			return null;
//		}
//		String query = "SELECT distinct firstmate FROM conf_failover "
//			+ " WHERE firstmate !=  '" + hostName + "'" ;
//		logger.info("About to issue query <" + query + ">");
//		Query q = new Query(query, "ctas");
//		if (! q.isValid()) {
//			logger.info("Returning partner as null because Invalid Query " + q);
//			return null;
//		}
//		Vector v = q.getResults();
//		if(v.size() < 1){  // v.size() != 1??
//			logger.info("Returning partner as null because "
//				+ v.size() + " rows returned from Query " + q);
//			return null;
//		}
//		HashMap h = (HashMap)v.elementAt(0);
//		String partner = (String)h.get("FIRSTMATE");
//		logger.info("Returning partner of " + hostName + " as " + partner);
//		return partner;
//	}


	private static CtasMsg getResponseFromCtasToIVRU_CALL_DISPOSITION(
		final CtasIvruCallDispositionRequestMsg req  // final CtasRequestMsg
	) {
		CtasMsg reqToCtas = newRequestToCtas_IVRU_CALL_DISPOSITION( req );
		CtasMsgIfc ctasIfc = newCtasMsgIfc(reqToCtas);
		logger.info("about to send IVRU_CALL_DISPOSITION msg <"
			+ reqToCtas + ">");
		CtasMsg response = ctasIfc.writeAndRead(reqToCtas);
		logger.info("received response to IVRU_CALL_DISPOSITION msg, rsp <"
			+ response + ">");
		ctasIfc.close();
		return response;
	}

	/**
	 * Construct a new "IVRU_CALL_DISPOSITION" CtasMsg to process the service request.
	 * Map the external client's service request to a request for
	 * an internal CTAS service.
	 *
	 * @param req  the service request from the client
	 * @return     a new, fully initialized "IVRU_CALL_DISPOSITION" CtasMsg
	 */
	private static CtasMsg newRequestToCtas_IVRU_CALL_DISPOSITION(
		CtasIvruCallDispositionRequestMsg req
	) {
//		boolean isEligible = isCircuitEligible( responseToGET );
//		String origin = getOrigin( req, isEligible );
//		int flowNum = getRequestFlowNum(isEligible, req.getRequestType());

		Map map = new HashMap();
		map.put( "MSGTYPE", "IVRU_CALL_DISPOSITION" );
		map.put( "ACK", "needed" );
		map.put( "FLOWNUM", String.valueOf(flowNum_) );
		map.put( "MINUTES", String.valueOf(minutes_) );
		//map.put( "ORIGIN", getOrigin(req) );
		// msg-specific content
        map.put("DISPOSITION_CODE", req.getCallDispositionCode());
		map.put("NOT_REACHED_REASON",
			( req.getNotReachedReason() != null ? req.getNotReachedReason() : "") );
		map.put("SYSTEM_ID", req.getSystemId());
        map.put("TRANSACTION_ID", req.getTransactionId());
        map.put("TIMESTAMP", timeStampFormat_.format( req.getTimeStamp() ));
		return new CtasMsg((HashMap)map);
	}

	/**
	 * Validate CTAS' response to the CTAS request corresponding to the client's
	 * service request.
	 *
	 * @param rsp  the intended response to the client, which may be modfied
	 *             as a side effect if the CTAS response is not valid.
	 * @return     <code>true</code> if and only if the CTAS response is valid;
	 *             <code>false</code> otherwise, in which case the service
	 *             response contains details.
	 */
	private static boolean isValidResponseToIVRU_CALL_DISPOSITION(
		final CtasMsg ctasRsp,
		CtasIvruCallDispositionResponseMsg rsp
	) {
		final String reason = "Failed to get Order Information";
		if (ctasRsp == null) {
			logger.warning("no response from CTAS");
			rsp.getResponseInfoAGR().set(
				ResponseCode.ProcessingError, reason );
			return false;
		}
		String rescode = ctasRsp.getValue("RESCODE");
		if (rescode == null) {
			logger.warning("missing RESCODE in CTAS's response");
			rsp.getResponseInfoAGR().set(
				ResponseCode.ProcessingError, reason );
			return false;
		} 
		return true;
	}

	/**
	 * Set the response to the client's service request based on the
	 * response from CTAS to corresponding internal service request.
	 *
	 * @param rsp          the response to the client, which will be modfied
	 *                     based on the CTAS response.
	 * @param rspFromCtas  the response from CTAS
	 *
	 */
	private static void setResponse(
		CtasIvruCallDispositionResponseMsg rsp,
		final CtasMsg rspFromCtas
	) {
		String rescode = rspFromCtas.getValue("RESCODE");
		String restext = rspFromCtas.getValue("RESTEXT");

		// Set ResponseInfoAGR
		int code = ResponseCode.UnknownError;
		String reason = restext;
		switch( Integer.parseInt(rescode) ) {
			case  0:
				code = ResponseCode.Ok;
				break;
			case -1:
				code = ResponseCode.ProcessingError;
				break;
			case -2:
				// Some error
				code = ResponseCode.ProcessingError;
				break;
			default:
				logger.warning(
					"unexpected RESCODE=" + rescode +
					" (RESTEXT=<" + restext +">)"
				);
				break;
		}
		rsp.getResponseInfoAGR().set( code, reason );
		logger.info( "exiting setResponse" );
	}

	public static CtasIvruCallDispositionResponseMsg processRequest(
		CtasIvruCallDispositionRequestMsg req
	) {
		long fromMilliSeconds = (new Date()).getTime();  // start service timer
		logger.info("Begin processing");
		req.toLog(logger);
		String clientString = getClientString(req);
		logger.info("received request from client " + clientString); 

		// Set defaults
		CtasIvruCallDispositionResponseMsg rsp =
			CtasIvruCallDispositionResponseMsg.getInstance(req);
		//rsp.setEligibilityFlag("N");

		try {
			if ( ! isValidRequest( req, rsp ) ) {
				logger.warning("Invalid client request: " +
					rsp.getResponseInfoAGR().getResponseReason() );
				return getFinalResponse(req, rsp, fromMilliSeconds);
			}
			// ASSERT: Valid client request

			// Send IVRU_CALL_DISPOSITION msg to Ctas & get CTAS' response
			CtasMsg responseToIVRU_CALL_DISPOSITION = getResponseFromCtasToIVRU_CALL_DISPOSITION( req );
			logger.info("for: " + clientString
				+ ", got Ctas response to IVRU_CALL_DISPOSITION: " + responseToIVRU_CALL_DISPOSITION);

			// Check for valid response from Ctas
			if ( ! isValidResponseToIVRU_CALL_DISPOSITION( responseToIVRU_CALL_DISPOSITION, rsp ) ) {
				logger.warning("Invalid response to IVRU_CALL_DISPOSITION from CTAS for <"
					+ clientString + ">: "
					+ rsp.getResponseInfoAGR().getResponseReason() );
				return getFinalResponse(req, rsp, fromMilliSeconds);
			}
			setResponse( rsp, responseToIVRU_CALL_DISPOSITION);

		} catch (Exception ex) {
			logger.severe("caught Exception, see app server stdout for stack trace: " + ex);
			ex.printStackTrace();
		} catch (Error err) {
			logger.severe("caught Error, see app server stdout for stack trace: " + err);
			err.printStackTrace();
		}

		return getFinalResponse(req, rsp, fromMilliSeconds);
	}

}

