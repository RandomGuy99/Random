package com.vz.ctas.ws.ivruCallDisposition;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.SimpleTimeZone;
import java.util.Properties;
import java.util.logging.Logger;
import java.util.regex.*;
import java.io.Serializable;
import com.vz.ctas.ws.common.CircuitEnd;
import com.vz.ctas.ws.common.CircuitEndAGR;
import com.vz.ctas.ws.common.CircuitEndId;
import com.vz.ctas.ws.common.ClientAGR;
import com.vz.ctas.ws.common.HdslBenchmarksAGR;
import com.vz.ctas.ws.common.LoopMeasurementsAGR;
import com.vz.ctas.ws.common.QuickTestResultsAGR;
import com.vz.ctas.ws.common.QuickTestResultsId;
import com.vz.ctas.ws.common.ResponseCode;
import com.vz.ctas.ws.common.ResponseInfoAGR;
import com.vz.ctas.ws.common.TurnUpStatusAGR;
import com.vz.ctas.ws.common.WebServiceUtils;

public class CtasIvruCallDispositionResponseMsg implements Serializable {
	private ResponseInfoAGR responseInfoAGR;
	private String systemId;
	private String transactionId;

	// Set and get methods
	public void setResponseInfoAGR( ResponseInfoAGR responseInfoAGR ) { this.responseInfoAGR=responseInfoAGR; }
	public ResponseInfoAGR getResponseInfoAGR() { return responseInfoAGR; }

	public void setSystemId( String systemId ) { this.systemId=systemId; }
	public String getSystemId() { return systemId; }

	public void setTransactionId( String transactionId ) { this.transactionId=transactionId; }
	public String getTransactionId() { return transactionId; }

	public String toString() {
		return ""
			+ "responseInfoAGR=<" + this.getResponseInfoAGR() + "> "
			+ "systemId=<" + this.getSystemId() + "> "
			+ "transactionId=<" + this.getTransactionId() + "> "
			;
	}

	public void toLog( Logger logger ) {
		logger.info("Start of client response ============================================");
		logger.info("responseInfoAGR = <" + this.getResponseInfoAGR() + ">");
		logger.info("systemId = <" + this.getSystemId() + ">");
		logger.info("transactionId = <" + this.getTransactionId() + ">");
		logger.info("End of client response ============================================");
	}


	// Factory methods --------------------------------------
	/**
	  @param
	  @return
	 */
	public static CtasIvruCallDispositionResponseMsg getInstance() {
		CtasIvruCallDispositionResponseMsg obj = new CtasIvruCallDispositionResponseMsg();
		obj.setResponseInfoAGR( new ResponseInfoAGR() );
		obj.getResponseInfoAGR().set(ResponseCode.UnknownError, "Unknown Error");
		obj.setSystemId( "" );
		obj.setTransactionId( "" );
		return obj;
	}

	/**
	  @param
	  @return
	 */
	public static CtasIvruCallDispositionResponseMsg getInstance(CtasIvruCallDispositionRequestMsg req) {
		CtasIvruCallDispositionResponseMsg obj = CtasIvruCallDispositionResponseMsg.getInstance();
		// Customize response here based on request
		return obj;
	}

}

