package com.vz.ctas.ws.ivruCallDisposition;

//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.Map;

import java.text.ParseException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Enumeration;
import java.util.Properties;
import java.util.logging.*;
import java.util.regex.*;

/**
 * Generic utility methods.
 */
public final class Utils {
	private static Logger logger = Logger.getLogger("Utils");
	private final static String YES = "Yes", NO = "No"; // capitalized
	/**
	 * Converts a boolean to String YES or NO.
	 * @param b    boolean value to be converted to yes/no String
	 * @return     YES iff <code>true</code>;
	 *             <code>false</code> otherwise
	 */
	public static String boolToYesNo( boolean b ) {
		return b ? YES : NO;
	}

	/**
	 * Converts a Yes"/NO string to boolean.
	 *
	 * @param yesNoEmpty  the YES/NO string, which may be
	 *                    <code>null</code> or empty
	 * @return            <code>false</code> if the string is <code>null</code>,
	 *                    empty, or doesn't start with "Y";
	 *                    <code>true</code> otherwise
	 */
	public static boolean yesNoToBool( String yesNoEmpty ) {
		if ( yesNoEmpty != null && yesNoEmpty.toUpperCase().startsWith("Y") ) {
			return true;
		} else {
			return false;
		}
	}

	public static Boolean yesNoToBoolean( String boolStr ) {
		return Boolean.valueOf(yesNoToBool(boolStr));
	}

	/**
	 * Converts a Boolean to String YES or NO.
	 * @param b    Boolean value to be converted to yes/no String
	 * @return     YES iff <code>true</code>;
	 *             <code>false</code> otherwise
	 */
	public static String BooleanToYesNo( Boolean b ) {
		//if ( b == null ) { return null; }
		//return boolToYesNo(b.booleanValue());
		return boolToYesNo(
			(b==null ? false : b.booleanValue() ));
	}

	/**
	 * Canonicalize a YES/NO string.
	 *
	 * @param yesNoEmpty  the YES/NO string, which may be
	 *                    <code>null</code> or empty.
	 * @return            NO if the string is <code>null</code>, empty, or
	 *                    doesn't start with "Y"; YES otherwise.
	 */
	public static String getYesNoEmpty( String yesNoEmpty ) {
		if ( yesNoEmpty != null && yesNoEmpty.startsWith("Y") ) {
			return YES;
		} else {
			return NO;
		}
	}

	private interface Patterns {
		// CLO validation
		Pattern validClo = Pattern.compile( "^[a-zA-Z]{3}\\d{9}$" );

		// Local-customer-contact phone number
		Pattern validLocalCustomerContactPhone = Pattern.compile("^\\d{3} \\d{3}-\\d{4}( x\\d{1,4})?$");

		// In range [-99.9,+99.9]
		Pattern validDbsxReceiveLevel = Pattern.compile("^[+-]?\\d{1,2}(\\.\\d)?$");

		// Postal addresses: White-space sequences
		Pattern blankablePostalChars = Pattern.compile( "\\s+" );

		// Postal addresses: Punctuation (exclude hyphen, which
		// appears in US zip+4 and in some street addresses
		Pattern deleteablePostalChars = Pattern.compile( "[,.]+" );
	}

	/**
	 *  Syntactic validation of CLO (aka Tracking Key)
	 */
	public static boolean isValidClo( String clo ) {
		return Patterns.validClo.matcher(clo).matches();
	}

	/**
	 *  Syntactic validation of Local-customer-contact phone number
	 */
	public static boolean isValidLocalCustomerContactPhone( String tn ) {
		Matcher m = Patterns.validLocalCustomerContactPhone.matcher( tn );
		return( m.matches() );
	}

	/**
	 *  Syntactic validation of dbsxReceiveLevel
	 */
	public static boolean isValidDbsxReceiveLevel( String level ) {
		Matcher m = Patterns.validDbsxReceiveLevel.matcher( level );
		return( m.matches() );
	}

	/**
	 * Returns true iff the specified postal-address strings match "fuzzily."
	 * Note that a zero-length address always returns true.
	 */
	public static boolean areEqualPostalAddresses( String a1, String a2 ) {
		if ( a1 == null || a2 == null) { return false; }

		// Construct "canonical" addresses from given addresses
		String a1c = getCanonicalPostalAddress(a1);
		String a2c = getCanonicalPostalAddress(a2);

		final int maxLen = 30;
		int safeLen = Math.min(maxLen,
			Math.min( a1c.length(), a2c.length() ));
		// ASSERT: safeLen = min( maxLen, a1c.length(), a2c.length() )
		//logger.info( safeLen + " <" + a1c + "> <" + a2c + ">" );
		return a1c.substring(0,safeLen).equals( a2c.substring(0,safeLen));
	}

	/**
	 * Canonicalize specified postal address.
	 * Trim leading and trailing white space, make all lower case,
	 * delete punctuation, collapse white space to single blanks.
	 */
	private static String getCanonicalPostalAddress(String addr) {
		if (addr == null) { return ""; }
		String canAddr = addr.trim().toLowerCase();
		       canAddr = Patterns.deleteablePostalChars.matcher(canAddr).replaceAll("");
		       canAddr = Patterns.blankablePostalChars.matcher(canAddr).replaceAll(" ");
		return canAddr;
	}

	/**
	 @parameter props  the Properties instance to search for the specified key
	 @parameter key    the property key
	 @return           (possibly null) String value of specified property key
	 */
	public static String getProp(Properties props, String key) {
		String propVal = props.getProperty(key, null);
		return propVal;
	}

	public static String getProp(Properties props, String arg, String defaultVal) {
		return props.getProperty(arg, defaultVal);
	}

	public static String getProp(Properties props, String arg, Integer defaultVal) {
		return props.getProperty(arg, String.valueOf(defaultVal));
	}

	public static Boolean getBooleanProp(Properties props, String propName) {
		String propVal = getProp(props, propName, (String)null);
		if (propVal == null) {
			return null;
		}
		// case insensitively map "true" to true; all else to false
		return Boolean.valueOf( propVal );
	}

	public static Integer getIntegerProp(Properties props, String propName) {
		return getIntegerProp(props, propName, null);
	}

	public static Integer getIntegerProp(
		Properties props, String propName, Integer defaultVal
	) {
		// return defaultVal if ( property not an integer OR key not in props )
		// defaultVal may be null
		Integer i = defaultVal;
		try {
			i = Integer.valueOf( getProp(props, propName, defaultVal) );
		} catch (NumberFormatException nfex) {
			logger.severe("Caught exception " + nfex
				+ ": propName=<" + propName + ">"
				+ " val=<" + getProp(props, propName) + ">"); //!
			nfex.printStackTrace();
		}
		return i;
	}

	public static Date getDateProp(
		Properties props, String propName
	) {
		return getDateProp(props, propName, "yyyy/MM/dd");
	}

	public static Date getDateProp(
		Properties props, String propName, String dateFormat
	) {
		String propVal = getProp(props, propName, (String)null);
		if (propVal == null) {
			return null;
		}
		Date date = null;
		try {
			date = new SimpleDateFormat("yyyy/MM/dd-HH:mm:ss-z")
			             .parse(propVal);
		} catch ( java.text.ParseException exObj ) {
			logger.severe("Caught exception " + exObj
				+ ": propName=<" + propName + ">"
				+ " val=<" + propVal + ">"); //!
			exObj.printStackTrace();
		}
		return date;
	}

	public static GregorianCalendar getGregorianCalendarProp(
		Properties props, String propName
	) {
		Date date = getDateProp(props, propName);
		if (date == null) {
			return null;
		}
		GregorianCalendar gcal = new GregorianCalendar();
		gcal.setLenient(false);
		gcal.setTime(date);
		return gcal;
	}

	/**
	 @return true IFF at least one property key (name) starts with the specified
	         string
	 */
	public static boolean anyPropNamesStartWith( Properties props, String prefix ) {
		// Ex: Let prefix=="Z.": return true IFF some key begins with "Z."
		for ( Enumeration keys = props.propertyNames(); keys.hasMoreElements();) {
			String key = (String)keys.nextElement();
			//logger.info("key=<"+key+">  prefix=<"+prefix+">");
			if ( key.startsWith(prefix) ) {
				//logger.info("return true");
				return true;
			}
		}
		//logger.info("return false");
		return false;
	}

}

