package com.vz.ctas.ws.ivruCallDisposition;

/**
 *  CTAS IvruCallDisposition Web Service
 *  @author <<<author>>>
 */

public final class IvruCallDisposition {
	public CtasIvruCallDispositionResponseMsg processRequest(
		CtasIvruCallDispositionRequestMsg req
	) {
		return(IvruCallDispositionImpl.processRequest(req));
	}
}

