package com.verizon.delphi.resource;




import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.MDC;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.verizon.delphi.service.FlowService;


@Component
@Path("/delphi")
public class FlowResource {
    


	private static final Logger logger = LoggerFactory
			.getLogger(FlowResource.class);
    
    @Autowired
    FlowService flowService;
    
    
    @GET
	@Path("/healthcheck")
	@Produces(MediaType.TEXT_PLAIN)
	public Response getHealthCheck() {
		
		String status="Flow service is up and running";
		return Response.status(200).entity(status).build();
	}
    
    
	 @POST
     @Path("/getTopology")
     @Produces(MediaType.APPLICATION_JSON)
     @Consumes(MediaType.APPLICATION_JSON)
     public Response getTopology(String input) {
         logger.info("getTopology :: Start"+input);

 		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObject = null;
		JSONObject jsonobj = null;
		try {
			jsonObject = (JSONObject) jsonParser.parse(input);
			String tid = (String) jsonObject.get("id");
			String user = (String) jsonObject.get("empId");
			MDC.put("TID", tid);
			MDC.put("USER", user);
			jsonobj = flowService.getTopology(input);
			if(null!=jsonobj){
				logger.info("getTopology :: End"+jsonobj.toString());
			return Response.status(200).entity(jsonobj).build();
			// return jsonobj.toString();
			}
			
			return Response.status(200).entity(jsonobj).build();		
		} catch (Exception e) {
			String errorResponse=e.getMessage();
			logger.error("Error while  getting getTopology response "+e.getMessage());
			return Response.status(Response.Status.BAD_REQUEST)
                    .entity(errorResponse).build();
		}
        
		     }
 	
}