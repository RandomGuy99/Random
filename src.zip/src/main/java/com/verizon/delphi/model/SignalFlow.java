package com.verizon.delphi.model;

import java.util.List;


public class SignalFlow  {

private String id;
private String label;
private List<NodeInfo> children;
public String getId() {
	return id;
}
public List<NodeInfo> getChildren() {
	return children;
}
public void setChildren(List<NodeInfo> children) {
	this.children = children;
}
public void setId(String id) {
	this.id = id;
}
public String getLabel() {
	return label;
}
public void setLabel(String label) {
	this.label = label;
}





	
 
}