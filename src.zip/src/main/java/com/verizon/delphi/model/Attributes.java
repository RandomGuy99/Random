package com.verizon.delphi.model;

import java.util.List;


public class Attributes  {

private List<NodeAttribute>  nodeAttribute;

public List<NodeAttribute> getNodeAttribute() {
	return nodeAttribute;
}

public void setNodeAttribute(List<NodeAttribute> nodeAttribute) {
	this.nodeAttribute = nodeAttribute;
}

/*private String nodeId;

public String getNodeId() {
	return nodeId;
}

public void setNodeId(String nodeId) {
	this.nodeId = nodeId;
}*/


}