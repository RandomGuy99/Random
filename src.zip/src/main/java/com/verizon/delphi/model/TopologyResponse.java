package com.verizon.delphi.model;

public class TopologyResponse  {
	
private Topology topology;

public Topology getTopology() {
	return topology;
}

public void setTopology(Topology topology) {
	this.topology = topology;
}
}