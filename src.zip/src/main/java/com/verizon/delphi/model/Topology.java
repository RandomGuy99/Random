package com.verizon.delphi.model;



public class Topology {

	private Attributes attributes;
	private SignalFlow signalFlow;
	private EquipmentView equipmentView;

	public EquipmentView getEquipmentView() {
		return equipmentView;
	}

	public void setEquipmentView(EquipmentView equipmentView) {
		this.equipmentView = equipmentView;
	}

	public Attributes getAttributes() {
		return attributes;
	}

	public void setAttributes(Attributes attributes) {
		this.attributes = attributes;
	}

	public SignalFlow getSignalFlow() {
		return signalFlow;
	}

	public void setSignalFlow(SignalFlow signalFlow) {
		this.signalFlow = signalFlow;
	}

}