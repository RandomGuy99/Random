package com.verizon.delphi.model;

import java.util.List;

import org.json.simple.JSONObject;

public class NeatInfo {

	private String tid;
	private String nodeclass;

	private String label;
	private List<AidsInfo> aidList;
	private String ownership;
	private List<String> availableCmds;
	private List<NetworkElements> networkList;
	public List<NetworkElements> getNetworkList() {
		return networkList;
	}

	public void setNetworkList(List<NetworkElements> networkList) {
		this.networkList = networkList;
	}
	private String role;
	private List<String> conditions;
	private String model;
	private List<NodeAttribute> nodeAttribute;
	private String degree;
	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	

	private JSONObject netassistresponse;

	public String getTid() {
		return tid;
	}

	public JSONObject getNetassistresponse() {
		return netassistresponse;
	}

	public void setNetassistresponse(JSONObject netassistresponse) {
		this.netassistresponse = netassistresponse;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	public String getNodeclass() {
		return nodeclass;
	}

	public void setNodeclass(String nodeclass) {
		this.nodeclass = nodeclass;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public List<AidsInfo> getAidList() {
		return aidList;
	}

	public void setAidList(List<AidsInfo> aidList) {
		this.aidList = aidList;
	}

	public String getOwnership() {
		return ownership;
	}

	public void setOwnership(String ownership) {
		this.ownership = ownership;
	}

	

	public List<String> getAvailableCmds() {
		return availableCmds;
	}

	public void setAvailableCmds(List<String> availableCmds) {
		this.availableCmds = availableCmds;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public List<String> getConditions() {
		return conditions;
	}

	public void setConditions(List<String> conditions) {
		this.conditions = conditions;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public List<NodeAttribute> getNodeAttribute() {
		return nodeAttribute;
	}

	public void setNodeAttribute(List<NodeAttribute> nodeAttribute) {
		this.nodeAttribute = nodeAttribute;
	}
}