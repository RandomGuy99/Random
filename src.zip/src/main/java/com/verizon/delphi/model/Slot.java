package com.verizon.delphi.model;

import java.util.ArrayList;
import java.util.List;

public class Slot {
	private String id;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<Card> getCardList() {
		if(cardList==null){
			cardList = new ArrayList<Card>();
		}
		return cardList;
	}

	private List<Card> cardList;
}
