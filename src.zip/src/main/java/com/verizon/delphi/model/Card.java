package com.verizon.delphi.model;

import java.util.ArrayList;
import java.util.List;

public class Card {
 private String id;
 private List<Port> portList;
 private List<Module> moduleList;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public List<Port> getPortList() {
	if(portList==null){
		portList = new ArrayList<Port>();
	}
	return portList;
}

public List<Module> getModuleList() {
	if(moduleList==null){
		moduleList = new ArrayList<Module>();
	}
	return moduleList;
}

}
