package com.verizon.delphi.model;

import java.util.ArrayList;
import java.util.List;

public class Shelf {
	private String id;
	private List<Slot> slotList;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<Slot> getSlotList() {
		if(slotList==null){
			slotList = new ArrayList<Slot>();
		}
		return slotList;
	}

}
