package com.verizon.delphi.model;

import java.util.ArrayList;
import java.util.List;

public class NetworkElements {
	private String id;
	private List<Shelf> shelfList;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<Shelf> getShelfList() {
		if(shelfList==null){
			shelfList = new ArrayList<Shelf>();
		}
		return shelfList;
	}


}
