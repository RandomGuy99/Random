package com.verizon.delphi.service;

import org.json.simple.JSONObject;


public interface FlowService {
    
   
 public JSONObject getTopology(String input)throws Exception;

 public JSONObject getNetAssistResponse(String tid) throws Exception;
}
