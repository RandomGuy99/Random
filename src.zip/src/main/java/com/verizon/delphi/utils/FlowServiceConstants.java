package com.verizon.delphi.utils;

public final class FlowServiceConstants {    

	 public static final String NEAT_SQL = "SELECT BASECONFIG FROM CONFNODEFILE WHERE MODEL=? AND TEMPLATE_TYPE=?"
		   		+ " AND VERSION IN(SELECT MAX(VERSION)FROM CONFNODEFILE WHERE MODEL=? AND TEMPLATE_TYPE=?)";
    
    public static final String BASECONFIG_COLUMN = "BASECONFIG";
    public static final String AID_TAG= "AID";
    public static final String NAME_ATTR = "Name";
    public static final String FORMAT_ATTR = "format";
    public static final String PARAMETER_TAG = "Parameter";
    public static final String KeyWord_TAG = "KeyWord";
    public static final String MODEL_ATTR = "Model";
    public static final String NODE_TAG = "Node";
    public static final String NODE_CLASS = "SFNode";
    public static final String OWNERSHIP = "VZT";
    public static final String AVAIALBLE_CMDS = "NEAT_TEST";
    public static final String ROLE = "MUX";
    
    public static final String SIGNAL_FLOW_DIAGRAM = "signal-flow-diagram";
    public static final String SIGNAL_FLOW = "signalFlow";
    public static final String EQUIMENT_VIEW_DIAGRAM="equipment-view-diagram";
    public static final String EQUIMENT_VIEW = "equipmentView";
    public static final String TOPOLOGY = "topology";
    public static final String CHILDREN = "children";
    public static final String  CLASS = "class";
    
    public static final String _CLASS = "_class";
    public static final String ATTRIBUTES = "attributes";
    public static final String NODE_ATTRIBUTE = "nodeAttribute";
    public static final String NODE_ID = "nodeId";
    
    public static final String XML_ENCODING = "UTF-8";
    
    public static final String FLOW_AVAILABLECMDS_SQL = "SELECT ROLE,OWNERSHIP,AVAILABLE_CMDS FROM CONFNODEFILE WHERE MODEL=? AND TEMPLATE_TYPE=?"
    		+ " AND VERSION IN(SELECT MAX(VERSION)FROM CONFNODEFILE WHERE MODEL=? AND TEMPLATE_TYPE=?)";
    
    private FlowServiceConstants(){
    }
        
} 