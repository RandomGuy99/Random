package com.verizon.delphi.dao;

import com.verizon.delphi.model.NeatSourceInfo;


public interface FlowDao {
    
    //public String getNeatXML(String tid);
    public String getNeatXML(String degree,String model);
    public NeatSourceInfo getAvaialableCmds(String degree,String model);
}
