package com.verizon.delphi.dao.impl;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.verizon.delphi.config.DbWrapper;
import com.verizon.delphi.dao.FlowDao;
import com.verizon.delphi.model.NeatSourceInfo;
import com.verizon.delphi.utils.FlowServiceConstants;


@Repository
public class FlowDaoImpl implements FlowDao {
	
	@Autowired
	DbWrapper dbWrapper;
    
	private static final Logger logger = LoggerFactory.getLogger(FlowDaoImpl.class);
    
    /**
     * this method reads neat xml from db
	 * @return  clobData
	 * @throws SQLException
	 */
	public String getNeatXML(String degree,String model) {
		logger.info("getNeatXML :: Start");
		Object[] data = new Object[] { model,degree,model,degree };
		SqlRowSet rs;
		logger.info("modelType"+model);
		logger.info("degree"+degree);
		String clobData = "";
		try {
			rs = dbWrapper.queryForRowSet(FlowServiceConstants.NEAT_SQL, data);

			while (rs.next()) {
				
				Clob clobObject = (Clob) rs
						.getObject(FlowServiceConstants.BASECONFIG_COLUMN);
				InputStream inputStream = clobObject.getAsciiStream();
				StringWriter writer = new StringWriter();
				
					IOUtils.copy(inputStream, writer);
				
				clobData = writer.toString();
				//logger.info("data" + clobData);
				return clobData;
			}
		} catch (Exception e) {
			logger.error(" error while reading  the NeatXml gfrom db"+e);
			e.printStackTrace();
		}
		logger.info("getNeatXML :: End");
		return clobData;
	}
	public NeatSourceInfo getAvaialableCmds(String degree,String model) {
		logger.info("getAvaialableCmds :: Start");
		Object[] data = new Object[] { model,degree,model,degree };
		SqlRowSet rs;
		String availableCmd="";
		List<String> availablCmdsList= new ArrayList<String>();
		NeatSourceInfo neatsourceinfo=new NeatSourceInfo();
		try {
			rs = dbWrapper.queryForRowSet(FlowServiceConstants.FLOW_AVAILABLECMDS_SQL, data);

			while (rs.next()) {
				neatsourceinfo.setRole(rs.getString("ROLE"));
				neatsourceinfo.setOwnership(rs.getString("OWNERSHIP"));
				availableCmd=rs.getString("AVAILABLE_CMDS");
				StringTokenizer st = new StringTokenizer(availableCmd, ",");
				while (st.hasMoreTokens()) {

					availablCmdsList.add(st.nextToken());
				}
				neatsourceinfo.setAvailableCmds(availablCmdsList);
				logger.info("getAvaialableCmds :: End");
				return neatsourceinfo;
			}
		} catch (Exception e) {
			logger.error(" error while reading AvaialableCmds from db"+e);
			e.printStackTrace();
		}
		logger.info("getAvaialableCmds :: End");
		return neatsourceinfo;
	}
}