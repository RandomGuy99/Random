package com.verizon.delphi.config;

import org.slf4j.MDC;
import org.springframework.boot.context.embedded.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.verizon.logging.LoggingFilter;
@Configuration
public class LoggingConfig {
	@Bean
	public FilterRegistrationBean filterRegistrationBean (){
		LoggingFilter loggingFilter=new LoggingFilter();
	    FilterRegistrationBean registrationBean = new FilterRegistrationBean();
	    registrationBean.setFilter(loggingFilter);
	    return registrationBean;
	}
}
