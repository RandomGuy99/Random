package com.verizon.delphi.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.glassfish.jersey.servlet.ServletContainer;
import org.glassfish.jersey.servlet.ServletProperties;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.embedded.ServletRegistrationBean;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.verizon.delphi.config.JerseyConfig;

@Configuration
@ComponentScan(basePackages = {"com.verizon.delphi"})
public class ServletHandlerLauncher extends SpringBootServletInitializer {

	private static final Logger logger = LoggerFactory
			.getLogger(ServletHandlerLauncher.class);
    
     
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(ServletHandlerLauncher.class);
    }

    /**
     * Instantiates a new ServletBean to receive the request for the the site-survey.
     * @return: ServletRegistrationBean
     */
    @Bean
    public ServletRegistrationBean jerseyServlet() {
    	
        ServletRegistrationBean registration = new ServletRegistrationBean(new ServletContainer(), "/services/*");
        try{        

        registration.addInitParameter(ServletProperties.JAXRS_APPLICATION_CLASS, JerseyConfig.class.getName());
        
        }catch(Exception e){
            logger.error(e.toString());
        }
        return registration;
    }
}
