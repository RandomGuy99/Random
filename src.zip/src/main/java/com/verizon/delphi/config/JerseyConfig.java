package com.verizon.delphi.config;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;

import com.verizon.delphi.resource.FlowHomeController;
import com.verizon.delphi.resource.FlowResource;


@Configuration
@ApplicationPath("/services/*")
@Controller
public class JerseyConfig extends ResourceConfig {

    /**
     * Configures Jersey, sets the resource path for the request filter.
     * With an executable war deployed as a containerless web application, the embedded tomcat
     * server fails to find the resource files for the ResourceConfig.
     * Include each of the endpoint resource class files.
     */
    public JerseyConfig() {
        super();
        register(RuntimeException.class);
        register(JacksonFeature.class);
        register(MultiPartFeature.class);
        register(FlowHomeController.class);
        register(FlowResource.class);
     
    }
}
