package com.verizon.delphi.config;

public class Greeting {


    private final String name;

    public String getName() {
		return name;
	}

	public Greeting(String name) {
               this.name = name;
    }

 
}
