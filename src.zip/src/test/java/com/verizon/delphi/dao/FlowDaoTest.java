package com.verizon.delphi.dao;


import static org.junit.Assert.fail;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.verizon.delphi.config.DbWrapper;
import com.verizon.delphi.config.FlowServiceApplication;
import com.verizon.delphi.dao.impl.FlowDaoImpl;



@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = FlowServiceApplication.class)
public class FlowDaoTest {

	@Autowired
	FlowDao flowDao;
	
	@Autowired
	DbWrapper dbWrapper;
	
/*	@Autowired
	DbWrapper dbWrappe1;*/

	@Test
	public void testGetNeatXML() throws Exception {

		
			
			String degree="2D";
			String model="Ciena6500T";
			
			Assert.assertNotNull(flowDao.getNeatXML(degree,model));
			
		
	}
	
	@Test
	//@Test(expected=Exception.class)
	public void testGetNeatXML_Exception() {
		
		try
		{
			String degree="2D";
			String model="Ciena6500T";
		FlowDaoImpl flowDao =new FlowDaoImpl();
		flowDao.getNeatXML(degree,model);
		
		}
		catch(Exception e)
		{
			Assert.fail();
		}
			
		
	}
	@Test
	public void testgetAvaialableCmds() {
			
		String degree="2D";
		String model="Ciena6500T";
		Assert.assertNotNull(flowDao.getAvaialableCmds(degree,model));
		
	}

	//@Test(expected=Exception.class)
	@Test
	public void testgetAvaialableCmds_Exception() {
		try {
			String degree="2D";
			String model="Ciena6500T";
		FlowDaoImpl flowDao =new FlowDaoImpl();
		flowDao.getAvaialableCmds(degree,model);
	   
		}
		catch(Exception e)
		{
			Assert.fail();
		}
		
	}
	
	
}