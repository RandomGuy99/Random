package com.verizon.delphi.service;


import org.json.simple.JSONObject;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import static org.mockito.Mockito.spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.verizon.delphi.config.FlowServiceApplication;
import com.verizon.delphi.service.impl.FlowServiceImpl;



@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = FlowServiceApplication.class)
public class FlowServiceTest {

	@Autowired
	FlowService flowService;
	
	@Autowired
	FlowServiceImpl flowServiceimpl;


@Test
	public void testGetTopology() {

	try{

	String params = "{'id': 'TWSNMDTW-01010416D','type': 'tidtype','region': 'ny','domain': 'dom','empId':'z662965','degree':'2D'}";
	params=params.replace("'", "\"");
	
			
		flowService.getTopology(params);

	}
	catch(Exception e){
		//Assert.fail();
	}
		
	}
@Test
public void testGetTopology_Model(){

	try{
		String params = "{'id': 'TWSNMDTW-01010416D','type': 'tidtype','region': 'ny','domain': 'dom','empId':'z662965','model':'CIENA_6500T','degree':'2D'}";
params=params.replace("'", "\"");

		
	flowService.getTopology(params);
	}

	catch(Exception e){
		//Assert.fail();
	}
}
	/*@Test
	public void testGetTopology_NetAssist_Exception()  {
		try
		{
			String params = "{'id': 'TWSNMDTW-01010416D','type': 'tidtype','region': 'ny','domain': 'dom','empId':'z662965','model':'Ciena6500T','degree':'2D'}";
			params=params.replace("'", "\"");
			//flowService.getTopology(params);
			
			FlowService spy = spy(flowService); 
			Exception exception=new Exception("Net Assist is down");
			//Mockito.doReturn(exception).when(spy.getTopology(params));
			Mockito.doThrow(exception).when(spy.getNetAssistResponse("TWSNMDTW-01010416D"));
			spy.getTopology(params);
		}
		
		catch(Exception e)
		{
			//Assert.fail();
		}
	}	*/
	@Test
	public void testGetTopology_NetAssist_Model_Exception()  {
		try
		{
			String params = "{'id': 'TWSNMDTW-01010416D','type': 'tidtype','region': 'ny','domain': 'dom','empId':'z662965','degree':'2D'}";
			params=params.replace("'", "\"");
			//flowService.getTopology(params);
			
			FlowService spy = spy(flowService); 
			//Mockito.when(spy.backendWrapper.getBackEndService("NgRoadmAccessMgr",params, "convertedReqXML")).thenReturn(responseXml);

			Exception exception=new Exception("Net Assist is down");
			//Mockito.doReturn(exception).when(spy.getNetAssistResponse("TWSNMDTW-01010416D"));
			/*Mockito.doThrow(exception).when(flowService.getNetAssistResponse("TWSNMDTW-01010416D"));
			flowService.getTopology(params);*/
			Mockito.doThrow(exception).when(spy).getNetAssistResponse("TWSNMDTW-01010416D");
			//Mockito.when(spy.getNetAssistResponse("TWSNMDTW-01010416D")).thenThrow(new NullPointerException());  
			JSONObject obj=flowService.getTopology(params);
		
			//Mockito.doNothing().doThrow(new RuntimeException()).when(spy).getNetAssistResponse("TWSNMDTW-01010416D");
		}
		
		catch(Exception e)
		{
			//Assert.fail();
		}
	}	
	@Test
	public void testGetTopology_Exception() {
		try
		{
			String params = "{'id': 'TWSNMDTW-01010416D','type': 'tidtype','region': 'ny','domain': 'dom','empId':'z662965','model':'Ciena6500T','degree':'2D'}";
			params=params.replace("'", "\"");
		  FlowServiceImpl flowService =new FlowServiceImpl();
		  flowService.getTopology(params);
		}
		catch(Exception e)
		{
			//Assert.fail();
		}
		
	}	
	
	
}