package com.verizon.delphi.resource;


import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.verizon.delphi.config.FlowServiceApplication;
import com.verizon.delphi.service.FlowService;



@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = FlowServiceApplication.class)
public class FlowResourceTest {

	@Autowired
	FlowResource flowResource;

	@Test
	public void testGetTopology() throws Exception {

			String params = "{'id': 'TWSNMDTW-01010416D','type': 'tidtype','region': 'ny','domain': 'dom','empId':'z662965','model':'Ciena6500T','degree':'2D'}";
			params=params.replace("'", "\"");
			
		Assert.assertNotNull(flowResource.getTopology(params));

			
		
	}
	@Test
	public void testGetTopology_Exception()  {
			try
			{
		   
	 		String params = "{'id': 'TWSNMDTW-01010416D','type': 'tidtype','region': 'ny','domain': 'dom','empId':'z662965','degree':'2D'}";
			params=params.replace("'", "\"");
			
			flowResource.getTopology(params);
			}
			catch(Exception e)
			{
				Assert.fail();
			}
	}	
	@Test
	public void testgetHealthCheck() throws Exception {

		Assert.assertNotNull(flowResource.getHealthCheck());

	}

		
}